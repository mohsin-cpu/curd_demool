const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

const uri = 'mongodb://localhost:27017';
const dbName = 'e-comm';
const collectionName = 'e-products';

const connectDB = async () => {
    const client = await MongoClient.connect(uri);
    const db = client.db(dbName);
    return db.collection(collectionName);
};

// Add a vehicle
app.post('/addVehicle', async (req, res) => {
    const collection = await connectDB();
    const { name, email, phone, address, brand, chassis } = req.body;
    const result = await collection.insertOne({ name, email, phone, address, brand, chassis });
    res.json(result);
});

// Get all vehicles
app.get('/getVehicles', async (req, res) => {
    const collection = await connectDB();
    const vehicles = await collection.find({}).toArray();
    res.json(vehicles);
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
